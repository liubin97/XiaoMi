create procedure addRemind(IN currend_sec_id int, IN now_time timestamp, IN v_emial varchar(45), OUT r_result int)
  BEGIN
		   declare insert_count int default 0;  /* insert_count判断插入是否成功  */
			 declare v_goods_name varchar(120);
			 declare v_seckill_time TIMESTAMP;
			 	
				START TRANSACTION;/* 开启事务 */
				/*获取秒杀产品名字和开始时间*/
			 select goods_name,seckill_starttime into v_goods_name,v_seckill_time from seckill_detail  where  seckill_id= currend_sec_id;
				
		
			insert ignore into sec_reminder(seckill_id,user_email,goods_name,reminder_starttime,reminder_status) values(currend_sec_id,v_emial,v_goods_name,v_seckill_time,0);
			select  row_count() into insert_count;
			 if (insert_count = 0 ) then /*出现重复提醒*/
					rollback;
					set r_result = 0;  /*重复提醒*/
			 elseif(insert_count < 0) then
				rollback;
				set r_result = -2; /*系统错误*/
				
			else
					commit ;/*提交事务*/
					set r_result = 1;/*秒杀成功*/
			end if;
			
END;

