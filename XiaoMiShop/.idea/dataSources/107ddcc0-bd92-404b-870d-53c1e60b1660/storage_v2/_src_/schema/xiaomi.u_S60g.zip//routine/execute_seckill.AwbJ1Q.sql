create procedure execute_seckill(IN v_seckill_id int, IN v_emial varchar(45), IN v_address_id int,
                                 IN v_kill_time  timestamp, OUT r_result int)
  BEGIN
   declare insert_count int default 0;  /* insert_countåˆ¤æ–­æ’å…¥success_killæ˜¯å¦æˆåŠŸ  */
	 declare orderkey int default 0;/*ä¿å­˜orderä¸»é”®*/
	 declare v_goods_detail_id int default 0;/*ç§’æ€id*/
	 declare v_sum_money float default 0;/*ç§’æ€é‡‘é¢*/
		
		/*èŽ·å–ç§’æ€äº§å“idå’Œé‡‘é¢*/
	 select goods_detail_id,seckill_money into v_goods_detail_id,v_sum_money 
						from seckill where seckill_id = v_seckill_id;
-- 	select v_goods_detail_id;
-- 	select v_sum_money;
						
	 START TRANSACTION;/* å¼€å¯äº‹åŠ¡ */
   insert ignore into success_killed(seckill_id,email,create_time) values(v_seckill_id,v_emial,v_kill_time);/*æ’å…¥ç§’æ€æˆåŠŸæ˜Žç»†*/
	 select  row_count() into insert_count;
	  if (insert_count = 0 ) then /*å‡ºçŽ°é‡å¤ç§’æ€*/
				rollback;
				set r_result = -1;  /*é‡å¤ç§’æ€*/
				elseif(insert_count < 0) then
				rollback;
				set r_result = -2; /*ç³»ç»Ÿé”™è¯¯*/
		else
	    	insert into `order`(user_email,sum_money,address_id,order_date,order_type,goods_num,order_status) values(v_emial,v_sum_money,v_address_id,v_kill_time,1,1,0);	/*æ’å…¥è®¢å•*/
				select  row_count() into insert_count;
				select  LAST_INSERT_ID() into orderkey;
-- 				select orderkey;
-- 					select insert_count;
				if (insert_count = 0) then
						rollback;
						set r_result = -1;  /*é‡å¤ç§’æ€*/
				elseif(insert_count < 0) then
						rollback;
						set r_result = -2; /*ç³»ç»Ÿé”™è¯¯*/		
				else
					insert into order_item(order_id,goods_detail_id,item_price,order_item_num) values(orderkey,v_goods_detail_id,v_sum_money,1);/*æ’å…¥è®¢å•item*/
					select  row_count() into insert_count;
					
					if (insert_count = 0) then
							rollback;
							set r_result = -1;  /*é‡å¤ç§’æ€*/
					elseif(insert_count < 0) then
							rollback;
							set r_result = -2; /*ç³»ç»Ÿé”™è¯¯*/		
					else
							update  seckill  set seckill_num=seckill_num-1 where seckill_id = v_seckill_id
							 and seckill_endtime > v_kill_time
							 and seckill_starttime < v_kill_time
							 and seckill_num > 0;/*æ›´æ–°åº“å­˜*/
				 
							select  row_count() into insert_count;
				 
							if (insert_count = 0) then
								rollback;
								set r_result = 0;  /*ç§’æ€ç»“æŸ*/
							elseif (insert_count < 0) then
								rollback;
								set r_result = -2;/*ç³»ç»Ÿé”™è¯¯*/		
							else
								commit ;/*æäº¤äº‹åŠ¡*/
								set r_result = 1;/*ç§’æ€æˆåŠŸ*/
							end if;
					end if;
			end if;
	end if;
						

END;

