create view seckill_detail as
  select
    `sec`.`seckill_id`        AS `seckill_id`,
    `sec`.`seckill_name`      AS `seckill_name`,
    `sec`.`seckill_money`     AS `seckill_money`,
    `sec`.`seckill_num`       AS `seckill_num`,
    `sec`.`seckill_starttime` AS `seckill_starttime`,
    `sec`.`seckill_endtime`   AS `seckill_endtime`,
    `sec`.`create_time`       AS `create_time`,
    `sec`.`seckill_status`    AS `seckill_status`,
    `gd`.`goods_detail_id`    AS `goods_detail_id`,
    `gd`.`kind`               AS `kind`,
    `gd`.`color`              AS `color`,
    `gd`.`prime_price`        AS `prime_price`,
    `g`.`goods_name`          AS `goods_name`,
    `g`.`goods_pic_url`       AS `goods_pic_url`
  from ((`xiaomi`.`seckill` `sec` left join `xiaomi`.`goods_detail` `gd`
      on ((`sec`.`goods_detail_id` = `gd`.`goods_detail_id`))) left join `xiaomi`.`goods` `g`
      on ((`gd`.`goods_id` = `g`.`goods_id`)));

