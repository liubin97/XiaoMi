create procedure close_seckill(IN nowtime datetime, OUT r_result int)
  BEGIN
     declare insert_count int default 0;  /* insert_count判断插入操作是否成功  */
		 declare end_flag varchar(50);/*定义判断变量*/
		 declare err int default 0;/*标识事务错误*/
		 declare v_seckill_id int;/*保存seckill id*/
		 declare v_goods_detail_id int;/*保存goods_detail_id*/
		 declare v_seckill_num int;/*保存goods_detail_id*/
		 declare cur_seckill cursor for select seckill_id,goods_detail_id,seckill_num from seckill where seckill_status=0 and seckill_endtime>= nowtime ;	/* 声明游标选取结束的秒杀活动的good_detail_id和seckill_id */
		 DECLARE CONTINUE HANDLER FOR NOT FOUND SET  end_flag = null; /* insert_count判断插入操作是否成功 ----异常处理 */
		 DECLARE CONTINUE HANDLER FOR SQLEXCEPTION SET err=1; /* 出现错误，设置为1，只要发生异常就回滚*/
		 
		 START TRANSACTION;/* 开启事务 */
		
		/*打开游标*/
		open cur_seckill;
		
		/*赋值*/
		fetch cur_seckill into v_seckill_id,v_goods_detail_id,v_seckill_num;  
		SELECT v_seckill_id,v_goods_detail_id,v_seckill_num;
		/*关闭秒杀操作--把state 置 1为2同时加回库存*/
		while (end_flag is not null) do
					update seckill set seckill_status=1 where seckill_id = v_seckill_id;/*关闭seckill*/
					/*发生异常，回滚*/
					if err=1 then
						rollback;
						set r_result =1;  /*关闭seckill异常*/
					else
						update goods_detail set stock=stock+v_seckill_num where goods_detail_id = v_goods_detail_id;
							if err=1 then
									rollback;
									set r_result =2;  /*更新库存异常*/
							else
									/*赋值下一条数据*/
									fetch  cur_seckill into v_seckill_id,v_goods_detail_id,v_seckill_num;  
							end if;
					end if;
		end while;
		/*关闭游标*/
		close cur_seckill;
				commit ;/*提交事务*/
			  set r_result = 1;/*更新成功*/		
				
		
					
						
					
							
					
					
					
		
		
		

END;

