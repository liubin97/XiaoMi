create procedure close_seckill(IN nowtime timestamp, OUT r_result int)
  BEGIN
     declare err int default 0;  /* insert_countåˆ¤æ–­æ’å…¥æ“ä½œæ˜¯å¦æˆåŠŸ  */
		 declare s int default 0;/*å®šä¹‰åˆ¤æ–­å˜é‡*/
		 declare v_seckill_id int;/*ä¿å­˜seckill id*/
		 declare v_goods_detail_id int;/*ä¿å­˜goods_detail_id*/
		 declare v_seckill_num int;/*ä¿å­˜goods_detail_id*/
		 declare cur_seckill cursor for select seckill_id,goods_detail_id,seckill_num from seckill where seckill_status=0 and seckill_endtime<= nowtime ;	/*Â å£°æ˜Žæ¸¸æ ‡é€‰å–ç»“æŸçš„ç§’æ€æ´»åŠ¨çš„good_detail_idå’Œseckill_idÂ */
		 DECLARE CONTINUE HANDLER FOR SQLSTATE '02000' SET s=1; /* insert_countåˆ¤æ–­æ’å…¥æ“ä½œæ˜¯å¦æˆåŠŸ ----å¼‚å¸¸å¤„ç† */
-- 		 	SELECT cur_seckill;
		 START TRANSACTION;/* å¼€å¯äº‹åŠ¡ */
		
		/*æ‰“å¼€æ¸¸æ ‡*/
		open cur_seckill;
		
		/*èµ‹å€¼*/
		fetch cur_seckill into v_seckill_id,v_goods_detail_id,v_seckill_num;  
-- 			SELECT v_seckill_id,v_goods_detail_id,v_seckill_num;
-- 		/*å…³é—­ç§’æ€æ“ä½œ--æŠŠstate ç½® 1ä¸º2åŒæ—¶åŠ å›žåº“å­˜*/
		 while s <> 1  do
				
					update seckill set seckill_status=1,seckill_num=0 where seckill_id = v_seckill_id;/*å…³é—­seckill*/
					select  row_count() into err;
					/*å‘ç”Ÿå¼‚å¸¸ï¼Œå›žæ»š*/
					if (err < 0) then
						rollback;
						set r_result = -1;  /*å…³é—­seckillå¼‚å¸¸*/
					else
						update goods_detail set stock=stock+v_seckill_num where goods_detail_id = v_goods_detail_id;
						select  row_count() into err;
						if (err < 0)then
									rollback;
									set r_result = -2;  /*æ›´æ–°åº“å­˜å¼‚å¸¸*/
							else
									/*èµ‹å€¼ä¸‹ä¸€æ¡æ•°æ®*/
									  fetch  cur_seckill into v_seckill_id,v_goods_detail_id,v_seckill_num;  
-- 										SELECT v_seckill_id,v_goods_detail_id,v_seckill_num;
							end if;
					end if;
		end while;
		/*å…³é—­æ¸¸æ ‡*/
		close cur_seckill;
				commit ;/*æäº¤äº‹åŠ¡*/
			  set r_result = 1;/*æ›´æ–°æˆåŠŸ*/		
				
		
					
						
					
							
					
					
					
		
		
		

END;

