create view selectallgroupbuyinfo as
  select
    `xiaomi`.`group_buy_info`.`goods_detail_id`       AS `goods_detail_id`,
    `xiaomi`.`goods_detail`.`goods_id`                AS `goods_id`,
    `xiaomi`.`group_buy_info`.`group_buy_info_id`     AS `group_buy_info_id`,
    `xiaomi`.`group_buy_info`.`group_num`             AS `group_num`,
    `xiaomi`.`group_buy_info`.`group_buy_price`       AS `group_buy_price`,
    `xiaomi`.`group_buy_info`.`group_starttime`       AS `group_starttime`,
    `xiaomi`.`group_buy_info`.`group_endtime`         AS `group_endtime`,
    `xiaomi`.`group_buy_info`.`group_buy_info_status` AS `group_buy_info_status`,
    `xiaomi`.`goods_detail`.`kind`                    AS `kind`,
    `xiaomi`.`goods_detail`.`color`                   AS `color`,
    `xiaomi`.`goods_detail`.`prime_price`             AS `prime_price`,
    `xiaomi`.`goods_detail`.`discount_price`          AS `discount_price`,
    `xiaomi`.`goods_detail`.`stock`                   AS `stock`,
    `xiaomi`.`goods_detail`.`goods_detail_status`     AS `goods_detail_status`,
    `xiaomi`.`goods`.`goods_category_id`              AS `goods_category_id`,
    `xiaomi`.`goods`.`goods_code`                     AS `goods_code`,
    `xiaomi`.`goods`.`goods_name`                     AS `goods_name`,
    `xiaomi`.`goods`.`video_set_url`                  AS `video_set_url`,
    `xiaomi`.`goods`.`goods_status`                   AS `goods_status`,
    `xiaomi`.`picture_set`.`picture_set_id`           AS `picture_set_id`,
    `xiaomi`.`picture_set`.`picture_set_url`          AS `picture_set_url`,
    `xiaomi`.`picture_set`.`picture_set_status`       AS `picture_set_status`
  from (((`xiaomi`.`group_buy_info`
    left join `xiaomi`.`goods_detail`
      on ((`xiaomi`.`group_buy_info`.`goods_detail_id` = `xiaomi`.`goods_detail`.`goods_detail_id`))) left join
    `xiaomi`.`goods` on ((`xiaomi`.`goods_detail`.`goods_id` = `xiaomi`.`goods`.`goods_id`))) left join
    `xiaomi`.`picture_set`
      on ((`xiaomi`.`group_buy_info`.`goods_detail_id` = `xiaomi`.`picture_set`.`goods_detail_id`)));

